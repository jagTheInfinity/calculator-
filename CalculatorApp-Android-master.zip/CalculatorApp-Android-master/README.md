# Calculator App 💜🔥

[![platform](https://img.shields.io/badge/platform-Android-brightgreen.svg?style=flat)](https://www.android.com)
[![API](https://img.shields.io/badge/API-16%2B-brightgreen.svg?style=flat)](https://android-arsenal.com/api?level=16)

[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/aniketjain)

### A Simple and Beautiful Calculator App.


## Screenshots

<p float="left">
	<img src="https://github.com/dev-aniketj/Calculator-app/blob/master/SS/video1.gif" height="500"/>
	<img src="https://github.com/dev-aniketj/Calculator-app/blob/master/SS/image1.jpg" height="500"/>
	<img src="https://github.com/dev-aniketj/Calculator-app/blob/master/SS/image2.jpg" height="500"/>
</p>


## Contributing

Please fork this repository and contribute back. Any contributions, large or small, major or minor features, bug fixes, are welcomed and appreciated but will be thoroughly reviewed.
#### Thank you.
